time=$(date +"%Y-%m-%d %H:%M:%S")
for x in exp/s1/tri1*/decode*; do [ -d $x ] && grep WER $x/wer_* | utils/best_wer.sh; \
done | sort -n -r -k2 > exp/s1/RESULTS.tri1.$USER.$timee
