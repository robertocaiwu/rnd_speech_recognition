# Copyright 2017 Roberto Cai
# Apache 2.0

#Now start preprocessing with KALDI scripts

if [ -f cmd.sh ]; then
      . cmd.sh; else
         echo "missing cmd.sh"; exit 1;
fi

#Path also sets LC_ALL=C for Kaldi, otherwise you will experience strange (and hard to debug!) bugs. It should be set here, after the python scripts and not at the beginning of this script
if [ -f path.sh ]; then
      . path.sh; else
         echo "missing path.sh"; exit 1;

fi

[ ! -L "steps" ] && ln -s ../../wsj/s5/steps

[ ! -L "utils" ] && ln -s ../../wsj/s5/utils

# mfccdir should be some place with a largish disk where you
# want to store MFCC features.
mfccdir=mfcc

utf8()
{
    iconv -f ISO-8859-1 -t UTF-8 $1 > $1.tmp
    mv $1.tmp $1
}

# Prepares KALDI dir structure and asks you where to store mfcc vectors and the final models (both can take up significant space)
#python local/prepare_dir_structure.py

# # Download German VoxForge dataset and extract it
# getdata.sh

# Adapt VoxForge dataset into TUDA format
#python local/Adapt_tuda.py

# Test/Train data prepare
RAWDATA=data/voxforge_train

# Filter by name
FILTERBYNAME="*.xml"

find $RAWDATA/$FILTERBYNAME -type f > data/waveIDs.txt
python local/find_waveID.py -d data/voxforge_train

RAWDATA_Test=../../kaldi-tuda-de/s5/data/wav/german-speechdata-package-v2
find $RAWDATA_Test/test/$FILTERBYNAME -type f >> data/waveIDs.txt

python local/data_prepare.py -f data/waveIDs.txt
for x in train test ; do
  utils/utt2spk_to_spk2utt.pl data/$x/utt2spk > data/$x/spk2utt
done
