cd ~/speech/kaldi/egs/voxforge/s5_de2/exp/s1/;
pwd;
echo "this is a test";
