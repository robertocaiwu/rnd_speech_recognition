if [ -f cmd.sh ]; then
      . cmd.sh; else
         echo "missing cmd.sh"; exit 1;
fi

if [ -f path.sh ]; then
      . path.sh; else
         echo "missing path.sh"; exit 1;
fi

export LC_ALL=C

echo "training jobs: $nJobs"
echo "decode jobs: $nDecodeJobs"
testDir=test

#time steps/decode.sh  --nj $nDecodeJobs --cmd "$decode_cmd" exp/tri1/graph data/$testDir exp/tri1/decode_test

time steps/decode.sh --nj $nDecodeJobs --cmd "$decode_cmd" exp/tri2b/graph data/$testDir exp/tri2b/decode_test

