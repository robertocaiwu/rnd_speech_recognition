time=$(date +"%Y-%m-%d %H:%M:%S")
#nnet3_chain/tdnn_sp_e2/decode_test
for x in exp/nnet3_chain/tdnn_sp*/decode*; do [ -d $x ] && grep WER $x/wer_* | utils/best_wer.sh; \
done | sort -n -r -k2 > exp/nnet3_chain/RESULTS.dnn.$USER.$timee

