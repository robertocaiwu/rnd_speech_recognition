[ ! -L "steps" ] && ln -s ../../wsj/s5/steps

[ ! -L "utils" ] && ln -s ../../wsj/s5/utils

# mfccdir should be some place with a largish disk where you
# want to store MFCC features.
mfccdir=mfcc

utf8()
{
    iconv -f ISO-8859-1 -t UTF-8 $1 > $1.tmp
    mv $1.tmp $1
}
# Prepares KALDI dir structure and asks you where to store mfcc vectors and the final models (both can take up significant space)

if [ -f cmd.sh ]; then
      . cmd.sh; else
         echo "missing cmd.sh"; exit 1;
fi

if [ -f path.sh ]; then
      . path.sh; else
         echo "missing path.sh"; exit 1;
fi

## Extract recordings to data/extracted directory and run the following:
#python local/Adapt_recordings_to_tuda.py
#python local/find_waveID.py

#python local/data_prepare_test.py -f data/waveID.txt
#for x in test4 test5 test6; do
#  utils/utt2spk_to_spk2utt.pl data/$x/utt2spk > data/$x/spk2utt
#done

nnet3_affix=_chain
dir=exp/nnet3${nnet3_affix}/tdnn_sp
train_ivector_dir=exp/nnet3${nnet3_affix}/ivectors_${train_set}_sp_hires_comb

for datadir in test4 test5 test6; do
    utils/fix_data_dir.sh data/${datadir} 
    steps/make_mfcc.sh --cmd "$train_cmd" --nj $nJobs data/${datadir} exp/make_mfcc_test/$datadir $mfccdir || exit 1;
    utils/fix_data_dir.sh data/${datadir} # some files fail to get mfcc for many reasons
    steps/compute_cmvn_stats.sh data/${datadir} exp/make_mfcc_test/$datadir $mfccdir || exit 1;
    utils/fix_data_dir.sh data/${datadir} # some files fail to get mfcc for many reasons
done

for datadir in test4 test5 test6; do
    time steps/decode.sh --nj $nDecodeJobs --cmd "$decode_cmd" \
         exp/s2/tri2b.2.2000.30000/graph data/$datadir exp/s2/tri2b.2.2000.30000/decode_${datadir}
done
#steps/nnet3/decode.sh --nj $nDecodeJobs --cmd "$decode_cmd" \
#   exp/nnet3_chain/tdnn_sp/graph data/test1 exp/nnet3_chain/tdnn_sp/decode1/

#for datadir in test1 test2 test3; do
#  utils/copy_data_dir.sh data/$datadir data/${datadir}_hires
#done

#for datadir in test1 test2 test3; do
#  steps/make_mfcc.sh --nj $nJobs --mfcc-config conf/mfcc_hires.conf \
#    --cmd "$train_cmd" data/${datadir}_hires
#  steps/compute_cmvn_stats.sh data/${datadir}_hires
#  utils/fix_data_dir.sh data/${datadir}_hires
#done
