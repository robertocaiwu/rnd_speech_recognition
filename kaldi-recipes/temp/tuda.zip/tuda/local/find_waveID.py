import os
import sys

if __name__ == '__main__':

    audiodir = ['test_f1mc', 'test_f05mc', 'test_s1mc']
    with open('data/waveID.txt', 'w') as waveid:
        for s in range(3):
            for file in os.listdir('data/' + audiodir[s]):
                if file.endswith(".xml"):
                    waveid.write('data/' + audiodir[s]+'/'+file+'\n')
