time=$(date +"%Y-%m-%d %H:%M:%S")
for x in exp/s2/tri2b.2.2000.30000/decode*; do [ -d $x ] && grep WER $x/wer_* | utils/best_wer.sh; \
done | sort -n -r -k2 > exp/RESULTS.recodings


